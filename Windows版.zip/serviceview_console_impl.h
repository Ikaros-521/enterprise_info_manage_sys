#ifndef SERVICEVIEWCONSOLEIMPL_H
#define SERVICEVIEWCONSOLEIMPL_H

#include "tools.h"
#include "service_impl.h"

class ServiceViewConsoleImpl
{
public:
	void service_sys(void);
	bool manager_login(void);
};

#endif//SERVICEVIEWCONSOLEIMPL_H
