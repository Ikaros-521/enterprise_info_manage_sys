﻿#include "emis.h"

Manager* m1[MAX_M];
int mid1 = 0,did1 = 0,eid1 = 0;
Manager* m[MAX_M];
Department* d[MAX_D];
Employee* e[MAX_E];
int mid = 0,did = 0,eid = 0;
