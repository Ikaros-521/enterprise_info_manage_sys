#ifndef MANAGERVIEW_H
#define MANAGERVIEW_H

class ManagerView
{
public:
	virtual void manager_sys(void) = 0;
};

#endif//MANAGERVIEW_H
