#ifndef MANAGERVIEWCONSOLEIMPL_H
#define MANAGERVIEWCONSOLEIMPL_H

#include "managerview.h"

class ManagerViewConsoleImpl:public ManagerView
{
public:
	void manager_sys(void);
};

#endif//MANAGERVIEWCONSOLEIMPL_H
